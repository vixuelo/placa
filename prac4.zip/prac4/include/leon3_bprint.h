#ifndef LEON3_BPRINT_H
#define LEON3_BPRINT_H

#include "leon3_types.h"

int8_t leon3_print_string (char *str);

int8_t leon3_print_uint8(uint8_t);

#endif
